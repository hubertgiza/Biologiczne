dane: https://www.kaggle.com/datasets/gowrishankarp/newspaper-text-summarization-cnn-dailymail
dokumentacja: https://github.com/hubertgiza/Biologiczne/tree/master/Projekt2/documentation.pdf
